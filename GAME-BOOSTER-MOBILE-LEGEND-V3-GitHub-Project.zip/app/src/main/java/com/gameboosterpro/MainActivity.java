package com.gameboosterpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private static final String ML_PACKAGE = "com.mobile.legends";
    private static final int BG = Color.rgb(9, 14, 22);
    private static final int PANEL = Color.rgb(21, 30, 42);
    private static final int GREEN = Color.rgb(0, 235, 155);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(159, 174, 192);

    private final DecimalFormat fmt = new DecimalFormat("0.0");
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView ramValue, storageValue, batteryValue, thermalValue, healthValue, recommendationValue;
    private PowerManager powerManager;
    private PowerManager.OnThermalStatusChangedListener thermalListener;
    private int thermalStatus = -1;

    private final Runnable refreshLoop = new Runnable() {
        @Override public void run() {
            refreshStats();
            handler.postDelayed(this, 5000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        buildScreen();
        registerThermalMonitor();
        showInitialShimmer();
    }

    private void showInitialShimmer() {
        final TextView[] targets = {healthValue, ramValue, storageValue, batteryValue, thermalValue};
        for (TextView target : targets) {
            if (target != null) target.setText("LOADING  •  MEMUAT DATA...");
        }
        final android.graphics.drawable.GradientDrawable shimmerBg = rounded(Color.rgb(35, 48, 62));
        final android.animation.ValueAnimator shimmer = android.animation.ValueAnimator.ofFloat(0.35f, 1f, 0.35f);
        shimmer.setDuration(850);
        shimmer.setRepeatCount(1);
        shimmer.addUpdateListener(a -> {
            float alpha = (Float) a.getAnimatedValue();
            for (TextView target : targets) if (target != null) target.setAlpha(alpha);
        });
        shimmer.start();
        handler.postDelayed(() -> {
            refreshStats();
            for (TextView target : targets) if (target != null) target.setAlpha(1f);
        }, 900);
    }

    private void attachPressAnimation(View view) {
        view.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.97f).scaleY(0.97f).alpha(0.88f)
                    .setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP ||
                       event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(150).setInterpolator(new DecelerateInterpolator()).start();
            }
            return false;
        });
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshLoop);
        handler.post(refreshLoop);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refreshLoop);
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 29 && thermalListener != null && powerManager != null) {
            powerManager.removeThermalStatusListener(thermalListener);
        }
        super.onDestroy();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(16));
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(28), dp(18), dp(26));
        scroll.addView(page);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView profile = new ImageView(this);
        profile.setImageResource(R.drawable.profile);
        profile.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable profileBg = rounded(PANEL);
        profile.setBackground(profileBg);
        profile.setClipToOutline(true);
        LinearLayout.LayoutParams profileLp = new LinearLayout.LayoutParams(dp(58), dp(58));
        profileLp.rightMargin = dp(12);
        brandRow.addView(profile, profileLp);
        TextView brandTitle = label("GAME BOOSTER\nMOBILE LEGEND", 21, GREEN, true);
        brandRow.addView(brandTitle);
        page.addView(brandRow);
        TextView subtitle = label("V2 • GAMING PERFORMANCE • NON-ROOT", 11, MUTED, true);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-2, -2);
        subLp.topMargin = dp(5);
        page.addView(subtitle, subLp);

        LinearLayout statusCard = card(page);
        healthValue = label("MENYIAPKAN ANALISIS...", 17, GREEN, true);
        statusCard.addView(healthValue);
        recommendationValue = label("Pantau kondisi perangkat sebelum bermain.", 13, MUTED, false);
        LinearLayout.LayoutParams recLp = new LinearLayout.LayoutParams(-1, -2);
        recLp.topMargin = dp(8);
        statusCard.addView(recommendationValue, recLp);

        TextView monitorTitle = label("LIVE DEVICE MONITOR", 13, WHITE, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-2, -2);
        titleLp.topMargin = dp(22);
        titleLp.bottomMargin = dp(10);
        page.addView(monitorTitle, titleLp);

        LinearLayout metrics = card(page);
        ramValue = addMetric(metrics, "RAM");
        storageValue = addMetric(metrics, "STORAGE");
        batteryValue = addMetric(metrics, "BATTERY");
        thermalValue = addMetric(metrics, "THERMAL");

        Button launch = makeButton("ANALISIS & BUKA MOBILE LEGENDS", GREEN, Color.BLACK);
        addButton(page, launch, 20);
        launch.setOnClickListener(v -> {
            refreshStats();
            showBoostPopup();
        });

        Button refresh = makeButton("PERBARUI ANALISIS", PANEL, WHITE);
        addButton(page, refresh, 9);
        refresh.setOnClickListener(v -> {
            refreshStats();
            showInfoPopup("ANALISIS DIPERBARUI", "Data RAM, penyimpanan, baterai, dan status thermal sudah diperbarui.");
        });

        Button settings = makeButton("BUKA PENGATURAN ANDROID", PANEL, WHITE);
        addButton(page, settings, 9);
        settings.setOnClickListener(v -> openAndroidSettings());

        Button appInfo = makeButton("PENGATURAN MOBILE LEGENDS", PANEL, WHITE);
        addButton(page, appInfo, 9);
        appInfo.setOnClickListener(v -> openMlSettings());

        TextView explanation = label(
            "APA YANG DILAKUKAN V2\n" +
            "• Memantau RAM, ruang kosong, baterai, dan suhu baterai.\\n" +
            "• Membaca status thermal Android pada perangkat yang mendukung API 29+.\\n" +
            "• Menganalisis kondisi dan memberi rekomendasi sebelum bermain.\\n" +
            "• Membuka Mobile Legends dan halaman pengaturan aplikasinya.\\n\\n" +
            "BATASAN NON-ROOT\n" +
            "Aplikasi biasa tidak dapat memaksa clock CPU/GPU, mengubah governor, " +
            "menghapus cache aplikasi lain, atau menjamin FPS naik. Gunakan Game Turbo/" +
            "Game Mode bawaan ponsel bila tersedia. Monitor diperbarui setiap 5 detik saat layar ini aktif.",
            12, MUTED, false);
        LinearLayout.LayoutParams expLp = new LinearLayout.LayoutParams(-1, -2);
        expLp.topMargin = dp(20);
        page.addView(explanation, expLp);

        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(rounded(PANEL));
        attachPressAnimation(box);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(15);
        parent.addView(box, lp);
        return box;
    }

    private TextView addMetric(LinearLayout parent, String name) {
        TextView t = label(name + ": membaca...", 14, WHITE, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        lp.bottomMargin = dp(8);
        parent.addView(t, lp);
        return t;
    }

    private Button makeButton(String title, int color, int textColor) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setBackground(rounded(color));
        attachPressAnimation(b);
        return b;
    }

    private void addButton(LinearLayout page, Button button, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(top);
        page.addView(button, lp);
    }

    private void registerThermalMonitor() {
        if (Build.VERSION.SDK_INT >= 29 && powerManager != null) {
            thermalStatus = powerManager.getCurrentThermalStatus();
            thermalListener = status -> {
                thermalStatus = status;
                refreshStats();
            };
            powerManager.addThermalStatusListener(command -> handler.post(command), thermalListener);
        }
    }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(memory);
        double availGb = memory.availMem / (1024.0 * 1024.0 * 1024.0);
        double totalGb = memory.totalMem / (1024.0 * 1024.0 * 1024.0);
        double usedPct = totalGb > 0 ? ((totalGb - availGb) / totalGb) * 100.0 : 0;
        ramValue.setText("RAM: " + fmt.format(availGb) + " GB tersedia / " +
                fmt.format(totalGb) + " GB • " + fmt.format(usedPct) + "% terpakai");

        StatFsData storage = readStorage();
        storageValue.setText("STORAGE: " + fmt.format(storage.free) + " GB kosong / " +
                fmt.format(storage.total) + " GB");

        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int tempC = -1, level = -1;
        if (battery != null) {
            int rawTemp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            if (rawTemp >= 0) tempC = rawTemp / 10;
            int rawLevel = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (rawLevel >= 0 && scale > 0) level = Math.round(rawLevel * 100f / scale);
        }
        batteryValue.setText("BATTERY: " + (level >= 0 ? level + "%" : "N/A") +
                (tempC >= 0 ? " • " + tempC + " °C" : " • suhu N/A"));

        String thermal = thermalLabel();
        thermalValue.setText("THERMAL: " + thermal);

        StringBuilder issues = new StringBuilder();
        boolean warning = false;
        if (memory.lowMemory || usedPct >= 85) {
            issues.append("RAM sedang tertekan. Tutup aplikasi berat yang tidak dipakai. ");
            warning = true;
        }
        if (tempC >= 40) {
            issues.append("Baterai panas; istirahatkan HP dan hindari bermain sambil mengisi daya. ");
            warning = true;
        }
        if (level >= 0 && level <= 20) {
            issues.append("Baterai rendah; isi daya sebelum sesi panjang. ");
            warning = true;
        }
        if (storage.free < 3.0) {
            issues.append("Ruang kosong rendah; kosongkan file pribadi yang tidak diperlukan. ");
            warning = true;
        }
        if (thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
            issues.append("Status thermal tinggi; tunggu perangkat mendingin sebelum bermain. ");
            warning = true;
        }

        if (warning) {
            healthValue.setText("CHECK: ADA KONDISI YANG PERLU DIPERHATIKAN");
            healthValue.setTextColor(Color.rgb(255, 190, 75));
            recommendationValue.setText(issues.toString().trim());
        } else {
            healthValue.setText("CHECK: KONDISI TERPANTAU NORMAL");
            healthValue.setTextColor(GREEN);
            recommendationValue.setText("Tidak ada ambang peringatan yang terdeteksi. Aktifkan Game Mode bawaan HP jika tersedia.");
        }
    }

    private static class StatFsData {
        double free, total;
    }

    private StatFsData readStorage() {
        StatFsData result = new StatFsData();
        android.os.StatFs stat = new android.os.StatFs(Environment.getDataDirectory().getPath());
        result.free = stat.getAvailableBytes() / (1024.0 * 1024.0 * 1024.0);
        result.total = stat.getTotalBytes() / (1024.0 * 1024.0 * 1024.0);
        return result;
    }

    private String thermalLabel() {
        if (Build.VERSION.SDK_INT < 29 || thermalStatus < 0) return "tidak didukung perangkat";
        switch (thermalStatus) {
            case PowerManager.THERMAL_STATUS_NONE: return "NORMAL";
            case PowerManager.THERMAL_STATUS_LIGHT: return "RINGAN";
            case PowerManager.THERMAL_STATUS_MODERATE: return "SEDANG";
            case PowerManager.THERMAL_STATUS_SEVERE: return "TINGGI";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "KRITIS";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "DARURAT";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "SHUTDOWN";
            default: return "tidak diketahui";
        }
    }

    private void showBoostPopup() {
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("🚀 BOOST SIAP")
            .setMessage("Analisis perangkat selesai.\n\n" +
                "GAME BOOSTER MOBILE LEGEND memantau kondisi HP dan menyiapkan akses cepat ke game.\n\n" +
                "Catatan: mode non-root tidak dapat memaksa kenaikan FPS atau mengubah clock CPU/GPU.")
            .setNegativeButton("NANTI", (d, which) -> d.dismiss())
            .setPositiveButton("BUKA MOBILE LEGENDS", (d, which) -> launchMobileLegends())
            .create();
        dialog.setOnShowListener(v -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(GREEN);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(MUTED);
        });
        dialog.show();
    }

    private void showInfoPopup(String title, String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("MENGERTI", (d, which) -> d.dismiss())
            .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(GREEN));
        dialog.show();
    }

    private void launchMobileLegends() {
        PackageManager pm = getPackageManager();
        Intent launch = pm.getLaunchIntentForPackage(ML_PACKAGE);
        if (launch == null) {
            showInfoPopup("GAME TIDAK DITEMUKAN", "Pastikan Mobile Legends sudah terpasang di perangkat ini.");
            return;
        }
        try {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (ActivityNotFoundException e) {
            showInfoPopup("GAGAL MEMBUKA GAME", "Mobile Legends tidak dapat dibuka. Coba jalankan dari ikon game.");
        }
    }

    private void openMlSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + ML_PACKAGE));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Pengaturan aplikasi tidak tersedia.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openAndroidSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Pengaturan Android tidak tersedia.", Toast.LENGTH_SHORT).show();
        }
    }
}
